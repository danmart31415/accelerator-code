import concurrent.futures
import multiprocessing
import serial
import time
import matplotlib.pyplot as plt
import csv
import pandas as pd
import os
from datetime import datetime
import numpy as np
import functions

def multiprocess(folders, files):
    # with concurrent.futures.ProcessPoolExecutor() as executor:
    #     result1 = executor.submit(functions.makePlots, folders, files)
    #     result2 = executor.submit(functions.find_zeros, folders, files)
    start = time.perf_counter()
    processes = []
    p = multiprocessing.Process(target = functions.makePlots, args = (folders, files))
    p2 = multiprocessing.Process(target = functions.find_zeros, args = (folders, files))
    processes.append(p)
    processes.append(p2)
    for process in processes:
        process.start()
        process.join()
    finish = time.perf_counter()
    print(f'finished in {finish-start}')
