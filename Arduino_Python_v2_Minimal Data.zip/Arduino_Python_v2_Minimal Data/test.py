import multiprocessing
import serial
import time
import matplotlib.pyplot as plt
import csv
import pandas as pd
import os
from datetime import datetime
import numpy as np

start = time.perf_counter()
datafiles = ["masterFile_test.csv"]
processes = []
def makePlots(folder1, masterFile1):
    now = datetime.now()
    PlotName = "plot_" + now.strftime("%m-%d-%Y_%H-%M-%S") + ".png"
    FinalPlotName = folder1 + '/' + PlotName
    master_file1 = folder1 + "/" + masterFile1
    AccDataAnalysis = pd.read_csv(master_file1)
    plt.plot(AccDataAnalysis.time,AccDataAnalysis.PhotoValue)
    plt.ylim(0,2023)
    plt.savefig(FinalPlotName)

def find_zeros(folder2, masterFile2):
    now = datetime.now()
    CrossTimesName = "crosstimes_" + now.strftime("%m-%d-%Y_%H-%M-%S") + ".csv"
    CrossTimes = folder2 + '/' + CrossTimesName
    master_file2 = folder2 + "/" + masterFile2
    with open(master_file2, "r") as data:
        with open(CrossTimes, "w") as crosstimes:
            for line in data:
                PhotoList = line.strip().split(',')
                firstValue = float(PhotoList[0])
                if PhotoList[0] in ['PhotoValue', '']:
                    pass
                elif firstValue <= 40:
                    for i in PhotoList:
                        float(i)
                    csv.writer(crosstimes, delimiter = ',').writerow(PhotoList)
if __name__ == '__main__':
        for file in datafiles:
            p = multiprocessing.Process(target = makePlots, args = ["C:/Users/Daniel/Desktop/Arduino_Python_v2", file])
            p2 = multiprocessing.Process(target = find_zeros, args = ["C:/Users/Daniel/Desktop/Arduino_Python_v2", file])
            p.start()
            p2.start()
            processes.append(p)
            processes.append(p2)
        for process in processes:
            process.join()

        finish = time.perf_counter()
        print(f'finished in {finish-start}')






    #
    #
    # def sleep_test():
    #     print('sleeping for one sec')
    #     time.sleep(6)
    #     print('done')
    #
    # processes = []
    #
    # if __name__ == '__main__':
    #     for _ in range(6):
    #         p = multiprocessing.Process(target = sleep_test)
    #         p.start()
    #         processes.append(p)
    #     for process in processes:
    #         process.join()
    #
