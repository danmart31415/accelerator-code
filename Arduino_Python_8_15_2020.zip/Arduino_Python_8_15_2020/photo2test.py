import serial
import time
import matplotlib.pyplot as plt
import csv
import pandas as pd
import os
from datetime import datetime
AccDataAnalysis = pd.read_csv("08-14-2020_23-37-04/Photo1.csv")
plt.plot(AccDataAnalysis.time, AccDataAnalysis.PhotoValue)
plt.savefig("plot1.png")
