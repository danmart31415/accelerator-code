import serial
import time
import matplotlib.pyplot as plt
import csv
import pandas as pd
import os
from datetime import datetime

now = datetime.now()
folder = now.strftime("%m-%d-%Y_%H-%M-%S")
os.makedirs(folder)
csvlist = ['Photo1.csv', 'Photo2.csv']#, "Photo3.csv", "Photo4.csv", "Photo5.csv", "Photo6.csv"]
plotlist = ['Plot1.png', 'Plot2.png']#, "Plot3.png", "Plot4.png", "Plot5.png", "Plot6.png"]
ser = serial.Serial('COM3', baudrate=9600 ,stopbits=2 , timeout=4)
masterFile = folder + '/' + 'master.csv'
with open(masterFile, 'w') as dataFile:
    data_writer = csv.writer(dataFile, delimiter=',')
    data_writer.writerow(['PhotoValue','time'])

# If I need them
t0 = time.time()
timeElapsed = 0
###############timeElapsed = time.time() - t0

while timeElapsed<=31.97:
    PhotoByte = ser.readline()
    PhotoString = PhotoByte.decode('utf-8').strip().split(',')
    print(PhotoString)
    timeElapsed = time.time() - t0

x = 1
while x==1:
    PhotoByte = ser.readline()
    PhotoString = PhotoByte.decode('utf-8').strip().split(',')
    with open(masterFile, 'a') as dataFile:
        data_writer = csv.writer(dataFile, delimiter=',')
        data_writer.writerow(PhotoString)#reading up to here
        print(PhotoString)
        if PhotoString[0] in ['done']:
            break

print('finished recording')
print('Starting Analysis')

for i in csvlist:
    AcceleratorData_file = i
    AcceleratorData = folder + '/' + AcceleratorData_file

    with open(AcceleratorData, 'w') as dataFile:
        data_writer = csv.writer(dataFile, delimiter=',')
        data_writer.writerow(['PhotoValue', 'time'])
    with open(masterFile, 'r') as datafile:
        csv_reader = csv.reader(datafile)
        with open(AcceleratorData, 'w') as dataFile:
            for line in csv_reader:
                data_writer = csv.writer(dataFile, delimiter=',')
                data_writer.writerow(line)

for n in plotlist:
    plotname_file = n
    plotname = folder + '/' + plotname_file
    AccDataAnalysis = pd.read_csv(masterFile)
    plt.plot(AccDataAnalysis.time,AccDataAnalysis.PhotoValue)
    plt.ylim(0,1023)
    plt.savefig(plotname)
# plt.close()
print('Analysis Done')
