import pandas as pd
import matplotlib.pyplot as plt
plotname = 'run_7_6_2020/run_7_6_2020.png'
AcceleratorData = 'run_7_6_2020' + '/' + 'AcceleratorData.csv'
AccDataAnalysis = pd.read_csv(AcceleratorData)
plt.plot(AccDataAnalysis.time,AccDataAnalysis.PHOTO1value)
plt.ylim(0,1023)
plt.savefig(plotname)
