import serial
import time
import matplotlib.pyplot as plt
import csv
import pandas as pd
import os
from datetime import datetime
import numpy as np

now = datetime.now()
folder = now.strftime("%m-%d-%Y_%H-%M-%S")
os.makedirs(folder)
csvlist = ['Photo1.csv', 'Photo2.csv']#, "Photo3.csv", "Photo4.csv", "Photo5.csv", "Photo6.csv"]
plotlist = ['Plot1.png', 'Plot2.png']#, "Plot3.png", "Plot4.png", "Plot5.png", "Plot6.png"]
ser = serial.Serial('COM3', baudrate=9600 ,stopbits=2 , timeout=4)
masterFile = folder + '/' + 'masterFile.csv'

fieldnames = ['PhotoValue','time']

with open(masterFile, 'w') as dataFile:
    data_writer = csv.DictWriter(dataFile, fieldnames=fieldnames)
    data_writer.writeheader()

# If I need them
t0 = time.time()
timeElapsed = 0
###############timeElapsed = time.time() - t0

# Added rstrip but might be able to just use strip. Test, and if something goes wrong just take out the r
while timeElapsed<=31.97:
    PhotoByte = ser.readline()
    PhotoList = PhotoByte.decode('utf-8').strip().split(',')
    print(PhotoList)
    timeElapsed = time.time() - t0
x = 1
while x==1:
    PhotoByte = ser.readline()
    PhotoList = PhotoByte.decode('utf-8').strip().split(',')
    if PhotoList[0] in ['done']:
        break
    for i in PhotoList:
        float(i)
    with open(masterFile, 'a') as dataFile:
        data_writer = csv.writer(dataFile, delimiter=',')
        data_writer.writerow(PhotoList)#reading up to here
    print(PhotoList)
print('finished recording')

print('Starting Analysis')
for i in csvlist:
    AcceleratorData_file = i
    AcceleratorData = folder + '/' + AcceleratorData_file
    with open(masterFile, 'r') as mfile:
        csv_reader = csv.reader(mfile)

        with open(AcceleratorData, 'w') as datafile:
            data_writer = csv.writer(dataFile, delimiter=',')
            data_writer1 = csv.DictWriter(dataFile, fieldnames=fieldnames)
            data_writer1.writeheader()

            for line in csv_reader:
                data_writer.writerow(line)

for n in plotlist:
    plotname_file = n
    plotname = folder + '/' + plotname_file
    AccDataAnalysis = pd.read_csv(masterFile)
    plt.plot(AccDataAnalysis.time,AccDataAnalysis.PhotoValue)
    plt.ylim(0,2023)
    plt.savefig(plotname)
print('Analysis Done')
